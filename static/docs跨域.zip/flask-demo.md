# flaskdemo
simple flask website demo

一个简单的flask网站

预览图

![demo](/store/flaskdemo/demo.png)

访问

[demo](http://www.landers1037.top/i/)

